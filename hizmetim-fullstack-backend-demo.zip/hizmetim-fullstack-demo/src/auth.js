const crypto = require('crypto');

const tokenSecret = () => process.env.TOKEN_SECRET || 'hizmetim-demo-secret-change-me';

function hashPassword(password){
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, 32);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

function verifyPassword(password, stored){
  try{
    const [kind,saltHex,hashHex] = String(stored).split('$');
    if(kind!=='scrypt') return false;
    const actual = crypto.scryptSync(String(password), Buffer.from(saltHex,'hex'), 32);
    const expected = Buffer.from(hashHex,'hex');
    return actual.length===expected.length && crypto.timingSafeEqual(actual,expected);
  }catch{return false;}
}

function b64url(input){ return Buffer.from(input).toString('base64url'); }
function signToken(user){
  const payload = { sub:user.id, role:user.role, name:user.name, exp:Date.now()+7*24*60*60*1000 };
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac('sha256', tokenSecret()).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function verifyToken(token){
  const [body,sig] = String(token||'').split('.');
  if(!body||!sig) return null;
  const expected = crypto.createHmac('sha256', tokenSecret()).update(body).digest('base64url');
  if(sig.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) return null;
  try{
    const payload=JSON.parse(Buffer.from(body,'base64url').toString('utf8'));
    if(!payload.exp || payload.exp<Date.now()) return null;
    return payload;
  }catch{return null;}
}
function authFromRequest(req){
  const h=req.headers.authorization||'';
  if(!h.startsWith('Bearer ')) return null;
  return verifyToken(h.slice(7));
}
module.exports={hashPassword,verifyPassword,signToken,verifyToken,authFromRequest};
