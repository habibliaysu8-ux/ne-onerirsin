const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { hashPassword } = require('./auth');

const DB_PATH = path.join(__dirname, '..', 'data', 'db.json');

const districts = [
  'Adalar','Arnavutköy','Ataşehir','Avcılar','Bağcılar','Bahçelievler','Bakırköy',
  'Başakşehir','Bayrampaşa','Beşiktaş','Beykoz','Beylikdüzü','Beyoğlu','Büyükçekmece',
  'Çatalca','Çekmeköy','Esenler','Esenyurt','Eyüpsultan','Fatih','Gaziosmanpaşa',
  'Güngören','Kadıköy','Kağıthane','Kartal','Küçükçekmece','Maltepe','Pendik',
  'Sancaktepe','Sarıyer','Silivri','Sultanbeyli','Sultangazi','Şile','Şişli',
  'Tuzla','Ümraniye','Üsküdar','Zeytinburnu'
];

const categories = [
  { slug:'ev-yemegi', name:'Ev Yemeği', icon:'🍲' },
  { slug:'ev-yapimi-gida', name:'Ev Yapımı Gıda', icon:'🫙' },
  { slug:'pasta', name:'Pasta', icon:'🍰' },
  { slug:'terzi', name:'Terzi & Dikiş', icon:'🧵' },
  { slug:'temizlik', name:'Temizlik', icon:'🧹' },
  { slug:'cilingir', name:'Çilingir', icon:'🔑' },
  { slug:'orgu-ceyiz', name:'Örgü & Çeyiz', icon:'🧶' },
  { slug:'organizasyon', name:'Organizasyon', icon:'🎈' },
  { slug:'kucuk-tamir', name:'Küçük Tamir', icon:'🛠️' }
];

function blankDb(){
  return { users:[], categories, stores:[], services:[], stories:[], reviews:[], conversations:[], messages:[], favorites:[] };
}

function readDb(){
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    const parsed = JSON.parse(raw || '{}');
    if (!Array.isArray(parsed.users)) return blankDb();
    return parsed;
  } catch {
    return blankDb();
  }
}

function writeDb(db){
  fs.mkdirSync(path.dirname(DB_PATH), { recursive:true });
  const tmp = DB_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(tmp, DB_PATH);
}

function id(prefix='id'){ return `${prefix}_${crypto.randomUUID()}`; }

async function seedDb(){
  const passwordHash = hashPassword('123456');
  const db = blankDb();

  const makeSeller = (name,email) => {
    const user = { id:id('usr'), name, email, passwordHash, role:'seller', createdAt:new Date().toISOString() };
    db.users.push(user); return user;
  };
  const customer = { id:id('usr'), name:'Demo Müşteri', email:'musteri@hizmetim.demo', passwordHash, role:'customer', createdAt:new Date().toISOString() };
  db.users.push(customer);

  const storeDefs = [
    // Tailors - Udemy style category list has several options
    ['Sevgi Terzi','sevgi-terzi','terzi','Başakşehir','Bahçeşehir','Paça, daraltma, fermuar ve özel dikim.','/assets/tailor-1.jpg','/assets/story-sevgi.jpg',4.9,96,3.2,true,['Paça|200','Fermuar|300','Daraltma|250','Elbise Tadilatı|400']],
    ['Ayşe Dikim Evi','ayse-dikim-evi','terzi','Başakşehir','Bahçeşehir','Günlük tadilat, perde dikimi ve hızlı paça.','/assets/tailor-2.jpg','/assets/tailor-2.jpg',4.8,74,1.8,true,['Paça|180','Fermuar|280','Perde Dikimi|350','Daraltma|230']],
    ['Moda Terzi','moda-terzi','terzi','Başakşehir','Bahçeşehir','Ceket, elbise ve abiye tadilatında uzman.','/assets/tailor-3.jpg','/assets/tailor-3.jpg',4.7,61,2.6,false,['Paça|190','Daraltma|240','Ceket Tadilatı|350']],
    ['Nil Tasarım','nil-tasarim','terzi','Başakşehir','Bahçeşehir','Abiye tadilatı ve kişiye özel küçük dikimler.','/assets/tailor-4.jpg','/assets/tailor-4.jpg',4.9,112,4.1,true,['Paça|220','Fermuar|300','Abiye Tadilat|660']],
    ['Emine Terzi','emine-terzi','terzi','Başakşehir','Bahçeşehir','Uygun fiyatlı günlük terzi işleri.','/assets/tailor-5.jpg','/assets/tailor-5.jpg',4.6,54,3.6,true,['Paça|170','Fermuar|250','Perde Dikimi|300']],
    ['Bahçeşehir Terzi','bahcesehir-terzi','terzi','Başakşehir','Bahçeşehir','Hızlı teslim paça, fermuar ve daraltma.','/assets/tailor-6.jpg','/assets/tailor-6.jpg',4.8,89,1.4,true,['Paça|160','Daraltma|220','Fermuar|240']],

    ['Nermin’in Mutfağı','nerminin-mutfagi','ev-yemegi','Başakşehir','Bahçeşehir','Günlük ev yemekleri, mantı ve sarma.','/assets/nermin-food.jpg','/assets/story-nermin.jpg',4.9,128,1.2,true,['Mantı 1 kg|450','Zeytinyağlı Sarma 1 kg|500','Ev Yemeği Menü|320']],
    ['Lezzetli Eller','lezzetli-eller','ev-yemegi','Bakırköy','Ataköy','Ev usulü günlük menüler ve börek.','/assets/nermin-food.jpg','/assets/nermin-food.jpg',4.8,83,7.4,true,['Günlük Menü|300','Börek 1 tepsi|700']],
    ['Anne Sofrası','anne-sofrasi','ev-yemegi','Kadıköy','Kozyatağı','Siparişe göre mantı, sarma ve zeytinyağlılar.','/assets/nermin-food.jpg','/assets/nermin-food.jpg',4.9,56,13.1,false,['Mantı 1 kg|480','Sarma 1 kg|520']],

    ['Annemin Salçası','annemin-salcasi','ev-yapimi-gida','Başakşehir','Bahçeşehir','Ev yapımı domates salçası, reçel ve turşu.','/assets/story-nermin.jpg','/assets/story-nermin.jpg',4.9,74,2.4,true,['Domates Salçası 1 kg|280','Çilek Reçeli 500 g|190','Turşu 1 kg|220']],
    ['Kavanoz Evim','kavanoz-evim','ev-yapimi-gida','Beylikdüzü','Adnan Kahveci','Mevsimlik ev yapımı kavanoz ürünleri.','/assets/story-nermin.jpg','/assets/story-nermin.jpg',4.7,38,8.2,true,['Biber Salçası 1 kg|310','Reçel 500 g|180']],

    ['Pasta Evi','pasta-evi','pasta','Bakırköy','Yeşilköy','Doğum günü ve özel gün pastaları.','/assets/pasta.jpg','/assets/pasta.jpg',4.9,41,8.5,true,['6 Kişilik Yaş Pasta|900','Butik Pasta|1250']],
    ['Tatlı Atölyesi','tatli-atolyesi','pasta','Başakşehir','Kayaşehir','Pasta, kurabiye ve cupcake siparişleri.','/assets/pasta.jpg','/assets/pasta.jpg',4.8,63,5.6,true,['Yaş Pasta|850','12 Cupcake|600']],

    ['Mutlu Temizlik','mutlu-temizlik','temizlik','Başakşehir','Bahçeşehir','Ev, ofis ve taşınma sonrası temizlik.','/assets/cleaning.jpg','/assets/story-cleaning.jpg',4.7,74,2.0,true,['2+1 Ev Temizliği|1200','3+1 Ev Temizliği|1500','Ofis Temizliği|1800']],
    ['Pratik Temizlik','pratik-temizlik','temizlik','Başakşehir','Kayaşehir','Günlük ve detaylı temizlik hizmeti.','/assets/cleaning.jpg','/assets/story-cleaning.jpg',4.8,132,5.2,false,['2+1 Ev Temizliği|1150','Detaylı Temizlik|1900']],

    ['Hızır Çilingir','hizir-cilingir','cilingir','Başakşehir','Bahçeşehir','Kapı açma ve kilit değişimi.','/assets/generic.jpg','/assets/generic.jpg',4.8,176,1.6,true,['Kapı Açma|650','Kilit Değişimi|850']],
    ['Anahtar Usta','anahtar-usta','cilingir','Esenyurt','Mehterçeşme','7/24 çilingir ve anahtar hizmeti.','/assets/generic.jpg','/assets/generic.jpg',4.7,91,6.1,true,['Kapı Açma|600','Kilit Değişimi|800']],

    ['Elif Örgü Evi','elif-orgu-evi','orgu-ceyiz','Başakşehir','Bahçeşehir','Bebek örgüsü, patik ve çeyiz ürünleri.','/assets/generic.jpg','/assets/generic.jpg',4.9,53,3.7,true,['Bebek Patik|150','Örgü Battaniye|900']],
    ['Çeyiz Sandığı','ceyiz-sandigi','orgu-ceyiz','Ümraniye','Atakent','Dantel, lif, havlu ve çeyizlik el işleri.','/assets/generic.jpg','/assets/generic.jpg',4.8,44,20.2,true,['Lif Seti|250','Dantel Havlu|400']],

    ['Mutlu Organizasyon','mutlu-organizasyon','organizasyon','Başakşehir','Bahçeşehir','Söz, nişan, doğum günü ve hediyelik hazırlığı.','/assets/pasta.jpg','/assets/pasta.jpg',4.9,154,3.1,true,['Masa Süsleme|3500','Hediyelik 50 adet|1600']],
    ['Mini Kutlama','mini-kutlama','organizasyon','Bakırköy','Florya','Evde küçük kutlama ve doğum günü hazırlığı.','/assets/pasta.jpg','/assets/pasta.jpg',4.7,47,10.2,false,['Mini Konsept|2500','Balon Süsleme|1200']],

    ['Usta Montaj','usta-montaj','kucuk-tamir','Başakşehir','Bahçeşehir','Raf, perde, avize ve küçük ev montajları.','/assets/generic.jpg','/assets/generic.jpg',4.8,98,2.8,true,['Raf Montajı|400','Avize Değişimi|500']],
    ['Pratik Tamir','pratik-tamir','kucuk-tamir','Küçükçekmece','Halkalı','Küçük ev tamirleri ve montaj işleri.','/assets/generic.jpg','/assets/generic.jpg',4.7,72,9.5,true,['Küçük Tamir|500','Perde Montajı|450']]
  ];

  for (let i=0;i<storeDefs.length;i++) {
    const [name,slug,categorySlug,district,neighborhood,description,cover,avatar,rating,reviewCount,distanceKm,availableToday,serviceDefs] = storeDefs[i];
    const seller = makeSeller(name, `${slug}@hizmetim.demo`);
    const store = {
      id:id('sto'), ownerId:seller.id, name, slug, categorySlug, city:'İstanbul', district, neighborhood,
      description, cover, avatar, rating, reviewCount, distanceKm, availableToday, verified:true,
      deliveryMethods: categorySlug==='ev-yemegi' || categorySlug==='ev-yapimi-gida' || categorySlug==='pasta'
        ? ['Elden teslim','Satıcı teslim eder','Müşteri kendi kuryesini gönderir']
        : ['Hizmet adresinde','Mağazadan teslim / karşılıklı anlaşma'],
      createdAt:new Date(Date.now()-i*3600000).toISOString()
    };
    db.stores.push(store);
    for (const def of serviceDefs) {
      const [serviceName, priceText] = def.split('|');
      db.services.push({ id:id('svc'), storeId:store.id, name:serviceName, price:Number(priceText), active:true, createdAt:new Date().toISOString() });
    }
  }

  // Seed stories for the lively home feed. These are refreshed on server start.
  const storyStores = db.stores.filter(s => ['nerminin-mutfagi','sevgi-terzi','pasta-evi','mutlu-temizlik'].includes(s.slug));
  const captions = {
    'nerminin-mutfagi':'Bugün taze salça ve mantı hazırladım 🍅',
    'sevgi-terzi':'Bugün yeni bir elbise tadilatını bitirdim ✂️',
    'pasta-evi':'Bugünün taze çilekli pastası hazır 🍓',
    'mutlu-temizlik':'Bugün 16:00 sonrası müsaitim ✨'
  };
  for (const s of storyStores) {
    db.stories.push({ id:id('sty'), storeId:s.id, image:s.avatar, caption:captions[s.slug], createdAt:new Date().toISOString(), expiresAt:new Date(Date.now()+86400000).toISOString(), seeded:true });
  }

  const sampleReviews = [
    ['nerminin-mutfagi','Mantısı çok güzeldi, yine sipariş vereceğim.',5],
    ['sevgi-terzi','Çok temiz çalışıyor ve hızlı teslim etti.',5],
    ['mutlu-temizlik','Zamanında geldi, memnun kaldım.',5],
    ['pasta-evi','Pasta tam istediğimiz gibiydi.',5]
  ];
  for (const [slug,text,rating] of sampleReviews) {
    const store = db.stores.find(s=>s.slug===slug);
    db.reviews.push({ id:id('rev'), storeId:store.id, userId:customer.id, rating, text, createdAt:new Date().toISOString() });
  }

  writeDb(db);
  return db;
}

async function initializeDb(){
  let db = readDb();
  if (!db.users || db.users.length===0 || !db.stores || db.stores.length===0) {
    db = await seedDb();
  } else {
    // Keep demo seeded stories visible after a later deployment/restart.
    const now = Date.now();
    db.stories = (db.stories || []).map(story => story.seeded ? {
      ...story,
      createdAt:new Date(now-15*60000).toISOString(),
      expiresAt:new Date(now+23*3600000).toISOString()
    } : story);
    db.categories = categories;
    writeDb(db);
  }
  return db;
}

module.exports = { DB_PATH, districts, categories, readDb, writeDb, initializeDb, id };
