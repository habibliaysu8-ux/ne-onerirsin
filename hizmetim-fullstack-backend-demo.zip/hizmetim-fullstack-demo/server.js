const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { readDb, writeDb, initializeDb, districts, categories, id } = require('./src/db');
const { hashPassword, verifyPassword, signToken, authFromRequest } = require('./src/auth');

const PORT = Number(process.env.PORT || 3000);
const PUBLIC = path.join(__dirname,'public');
const MAX_BODY = 8 * 1024 * 1024;

class HttpError extends Error { constructor(status,message){ super(message); this.status=status; } }
function json(res,status,data){ const body=JSON.stringify(data); res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(body)}); res.end(body); }
function publicUser(u){ return u?{id:u.id,name:u.name,email:u.email,role:u.role,createdAt:u.createdAt}:null; }
function storeWithServices(db,store){ const services=db.services.filter(s=>s.storeId===store.id&&s.active!==false); return {...store,services,minPrice:services.length?Math.min(...services.map(s=>s.price)):null}; }
function activeStories(db){ const now=Date.now(); return (db.stories||[]).filter(s=>!s.expiresAt||new Date(s.expiresAt).getTime()>now).map(story=>{const store=db.stores.find(s=>s.id===story.storeId);return store?{...story,store:{id:store.id,name:store.name,avatar:store.avatar,categorySlug:store.categorySlug,district:store.district,neighborhood:store.neighborhood}}:null}).filter(Boolean); }
function requireAuth(ctx,role){ const auth=authFromRequest(ctx.req); if(!auth) throw new HttpError(401,'Giriş yapmanız gerekiyor.'); if(role&&auth.role!==role) throw new HttpError(403,`Bu işlem için ${role==='seller'?'mağaza sahibi':'müşteri'} hesabı gerekiyor.`); return auth; }
async function body(req){
  return await new Promise((resolve,reject)=>{ let size=0; const chunks=[]; req.on('data',c=>{size+=c.length;if(size>MAX_BODY){reject(new HttpError(413,'Gönderilen dosya çok büyük.'));req.destroy();return;}chunks.push(c)}); req.on('end',()=>{if(!chunks.length)return resolve({});try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')))}catch{reject(new HttpError(400,'Geçersiz JSON verisi.'))}}); req.on('error',reject); });
}

const routes=[];
function add(method, pattern, handler){ routes.push({method,pattern,handler}); }
function routeParams(match,names=[]){ const out={}; names.forEach((n,i)=>out[n]=decodeURIComponent(match[i+1])); return out; }

add('GET',/^\/api\/health$/,async ctx=>({ok:true,app:'Hizmetim',time:new Date().toISOString()}));
add('GET',/^\/api\/config$/,async ctx=>({city:'İstanbul',districts,categories}));

add('POST',/^\/api\/auth\/register$/,async ctx=>{
  const b=await body(ctx.req); const {name,email,password,role='customer'}=b;
  if(!name||!email||!password) throw new HttpError(400,'Ad, e-posta ve şifre zorunlu.');
  if(!['customer','seller'].includes(role)) throw new HttpError(400,'Geçersiz hesap türü.');
  if(String(password).length<6) throw new HttpError(400,'Şifre en az 6 karakter olmalı.');
  const db=readDb(), normalized=String(email).trim().toLowerCase();
  if(db.users.some(u=>u.email.toLowerCase()===normalized)) throw new HttpError(409,'Bu e-posta zaten kayıtlı.');
  const user={id:id('usr'),name:String(name).trim(),email:normalized,passwordHash:hashPassword(password),role,createdAt:new Date().toISOString()};
  db.users.push(user);writeDb(db);return {status:201,data:{token:signToken(user),user:publicUser(user)}};
});
add('POST',/^\/api\/auth\/login$/,async ctx=>{
  const b=await body(ctx.req), db=readDb(); const user=db.users.find(u=>u.email.toLowerCase()===String(b.email||'').trim().toLowerCase());
  if(!user||!verifyPassword(b.password||'',user.passwordHash)) throw new HttpError(401,'E-posta veya şifre hatalı.');
  return {token:signToken(user),user:publicUser(user)};
});
add('GET',/^\/api\/me$/,async ctx=>{ const auth=requireAuth(ctx),db=readDb(),user=db.users.find(u=>u.id===auth.sub);if(!user)throw new HttpError(404,'Kullanıcı bulunamadı.');const store=db.stores.find(s=>s.ownerId===user.id);return{user:publicUser(user),store:store?storeWithServices(db,store):null}; });

add('GET',/^\/api\/home$/,async ctx=>{ const db=readDb(); const featured=db.stores.map(s=>storeWithServices(db,s)).sort((a,b)=>(b.rating*100+b.reviewCount)-(a.rating*100+a.reviewCount)).slice(0,8); return {city:'İstanbul',categories,stories:activeStories(db),featured}; });
add('GET',/^\/api\/categories\/([^/]+)\/stores$/,async ctx=>{
  const slug=ctx.match[1]; if(!categories.some(c=>c.slug===slug))throw new HttpError(404,'Kategori bulunamadı.');
  const db=readDb(); let stores=db.stores.filter(s=>s.categorySlug===slug).map(s=>storeWithServices(db,s));
  const sp=ctx.url.searchParams,district=sp.get('district'),minPrice=sp.get('minPrice'),maxPrice=sp.get('maxPrice'),sort=sp.get('sort')||'nearby',q=sp.get('q'),availableToday=sp.get('availableToday');
  if(district)stores=stores.filter(s=>s.district===district);
  if(q){const n=q.toLocaleLowerCase('tr');stores=stores.filter(s=>[s.name,s.description,s.neighborhood,s.district,...s.services.map(x=>x.name)].join(' ').toLocaleLowerCase('tr').includes(n));}
  if(minPrice!==null&&minPrice!=='')stores=stores.filter(s=>s.minPrice!=null&&s.minPrice>=Number(minPrice));
  if(maxPrice!==null&&maxPrice!=='')stores=stores.filter(s=>s.minPrice!=null&&s.minPrice<=Number(maxPrice));
  if(availableToday==='true')stores=stores.filter(s=>s.availableToday);
  if(sort==='price')stores.sort((a,b)=>(a.minPrice??999999)-(b.minPrice??999999));else if(sort==='rating')stores.sort((a,b)=>b.rating-a.rating||b.reviewCount-a.reviewCount);else stores.sort((a,b)=>a.distanceKm-b.distanceKm);
  return {category:categories.find(c=>c.slug===slug),count:stores.length,stores};
});
add('GET',/^\/api\/stores\/([^/]+)$/,async ctx=>{
  const db=readDb(),key=ctx.match[1],store=db.stores.find(s=>s.id===key||s.slug===key);if(!store)throw new HttpError(404,'Mağaza bulunamadı.');
  const auth=authFromRequest(ctx.req); const reviews=db.reviews.filter(r=>r.storeId===store.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).map(r=>({...r,user:publicUser(db.users.find(u=>u.id===r.userId))}));
  return {store:storeWithServices(db,store),reviews,stories:activeStories(db).filter(s=>s.storeId===store.id),isFavorite:auth?db.favorites.some(f=>f.userId===auth.sub&&f.storeId===store.id):false};
});

add('POST',/^\/api\/stores$/,async ctx=>{
  const auth=requireAuth(ctx,'seller'),b=await body(ctx.req),db=readDb();if(db.stores.some(s=>s.ownerId===auth.sub))throw new HttpError(409,'Bu hesapla zaten bir mağaza açılmış.');
  const {name,categorySlug,district,neighborhood='',description='',deliveryMethods=[]}=b;if(!name||!categorySlug||!district)throw new HttpError(400,'Mağaza adı, kategori ve ilçe zorunlu.');if(!categories.some(c=>c.slug===categorySlug))throw new HttpError(400,'Geçersiz kategori.');if(!districts.includes(district))throw new HttpError(400,'İstanbul ilçelerinden birini seçin.');
  const store={id:id('sto'),ownerId:auth.sub,name:String(name).trim(),slug:`${String(name).trim().toLocaleLowerCase('tr').replace(/[^a-z0-9çğıöşü]+/gi,'-')}-${Date.now().toString().slice(-4)}`,categorySlug,city:'İstanbul',district,neighborhood,description,cover:'/assets/generic.jpg',avatar:'/assets/generic.jpg',rating:0,reviewCount:0,distanceKm:1,availableToday:true,verified:false,deliveryMethods:Array.isArray(deliveryMethods)?deliveryMethods:[],createdAt:new Date().toISOString()};
  db.stores.push(store);writeDb(db);return{status:201,data:{store:storeWithServices(db,store)}};
});
add('PUT',/^\/api\/stores\/([^/]+)$/,async ctx=>{
  const auth=requireAuth(ctx,'seller'),db=readDb(),store=db.stores.find(s=>s.id===ctx.match[1]);if(!store)throw new HttpError(404,'Mağaza bulunamadı.');if(store.ownerId!==auth.sub)throw new HttpError(403,'Bu mağazayı düzenleyemezsiniz.');const b=await body(ctx.req);for(const k of ['name','district','neighborhood','description','availableToday','deliveryMethods','avatar','cover'])if(b[k]!==undefined)store[k]=b[k];writeDb(db);return{store:storeWithServices(db,store)};
});
add('POST',/^\/api\/stores\/([^/]+)\/services$/,async ctx=>{
  const auth=requireAuth(ctx,'seller'),db=readDb(),store=db.stores.find(s=>s.id===ctx.match[1]);if(!store)throw new HttpError(404,'Mağaza bulunamadı.');if(store.ownerId!==auth.sub)throw new HttpError(403,'Bu mağazaya hizmet ekleyemezsiniz.');const b=await body(ctx.req);if(!b.name||!Number.isFinite(Number(b.price))||Number(b.price)<0)throw new HttpError(400,'Hizmet adı ve geçerli fiyat zorunlu.');const service={id:id('svc'),storeId:store.id,name:String(b.name).trim(),price:Number(b.price),active:true,createdAt:new Date().toISOString()};db.services.push(service);writeDb(db);return{status:201,data:{service}};
});
add('POST',/^\/api\/stories$/,async ctx=>{
  const auth=requireAuth(ctx,'seller'),db=readDb(),store=db.stores.find(s=>s.ownerId===auth.sub);if(!store)throw new HttpError(400,'Önce mağaza açmanız gerekiyor.');const b=await body(ctx.req);if(!b.imageData||!String(b.imageData).startsWith('data:image/'))throw new HttpError(400,'Story için bir fotoğraf seçin.');if(String(b.imageData).length>7_000_000)throw new HttpError(413,'Fotoğraf çok büyük. Daha küçük bir fotoğraf seçin.');const story={id:id('sty'),storeId:store.id,image:b.imageData,caption:String(b.caption||'').slice(0,180),createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+86400000).toISOString(),seeded:false};db.stories.push(story);writeDb(db);return{status:201,data:{story}};
});
add('POST',/^\/api\/stores\/([^/]+)\/reviews$/,async ctx=>{
  const auth=requireAuth(ctx,'customer'),db=readDb(),store=db.stores.find(s=>s.id===ctx.match[1]);if(!store)throw new HttpError(404,'Mağaza bulunamadı.');const b=await body(ctx.req),rating=Number(b.rating),text=String(b.text||'').trim();if(!Number.isInteger(rating)||rating<1||rating>5||!text)throw new HttpError(400,'1-5 puan ve yorum yazısı zorunlu.');const review={id:id('rev'),storeId:store.id,userId:auth.sub,rating,text:text.slice(0,500),createdAt:new Date().toISOString()};db.reviews.push(review);store.rating=Number((((store.rating*store.reviewCount)+rating)/(store.reviewCount+1)).toFixed(2));store.reviewCount+=1;writeDb(db);return{status:201,data:{review}};
});
add('POST',/^\/api\/favorites\/([^/]+)$/,async ctx=>{const auth=requireAuth(ctx,'customer'),db=readDb(),store=db.stores.find(s=>s.id===ctx.match[1]);if(!store)throw new HttpError(404,'Mağaza bulunamadı.');const idx=db.favorites.findIndex(f=>f.userId===auth.sub&&f.storeId===store.id);let favorite=true;if(idx>=0){db.favorites.splice(idx,1);favorite=false}else db.favorites.push({id:id('fav'),userId:auth.sub,storeId:store.id,createdAt:new Date().toISOString()});writeDb(db);return{favorite};});
add('GET',/^\/api\/favorites$/,async ctx=>{const auth=requireAuth(ctx,'customer'),db=readDb(),ids=db.favorites.filter(f=>f.userId===auth.sub).map(f=>f.storeId);return{stores:db.stores.filter(s=>ids.includes(s.id)).map(s=>storeWithServices(db,s))};});

add('POST',/^\/api\/conversations$/,async ctx=>{const auth=requireAuth(ctx,'customer'),b=await body(ctx.req),db=readDb(),store=db.stores.find(s=>s.id===b.storeId);if(!store)throw new HttpError(404,'Mağaza bulunamadı.');let c=db.conversations.find(c=>c.customerId===auth.sub&&c.storeId===store.id);if(!c){c={id:id('con'),customerId:auth.sub,sellerId:store.ownerId,storeId:store.id,createdAt:new Date().toISOString()};db.conversations.push(c);writeDb(db)}return{conversation:c};});
add('GET',/^\/api\/conversations$/,async ctx=>{const auth=requireAuth(ctx),db=readDb();const list=db.conversations.filter(c=>c.customerId===auth.sub||c.sellerId===auth.sub).map(c=>{const store=db.stores.find(s=>s.id===c.storeId),messages=db.messages.filter(m=>m.conversationId===c.id).sort((a,b)=>new Date(a.createdAt)-new Date(b.createdAt)),otherId=c.customerId===auth.sub?c.sellerId:c.customerId;return{...c,store:store?{id:store.id,name:store.name,avatar:store.avatar}:null,other:publicUser(db.users.find(u=>u.id===otherId)),lastMessage:messages.at(-1)||null}}).sort((a,b)=>new Date(b.lastMessage?.createdAt||b.createdAt)-new Date(a.lastMessage?.createdAt||a.createdAt));return{conversations:list};});
add('GET',/^\/api\/conversations\/([^/]+)\/messages$/,async ctx=>{const auth=requireAuth(ctx),db=readDb(),c=db.conversations.find(c=>c.id===ctx.match[1]);if(!c)throw new HttpError(404,'Görüşme bulunamadı.');if(c.customerId!==auth.sub&&c.sellerId!==auth.sub)throw new HttpError(403,'Bu görüşmeyi göremezsiniz.');return{messages:db.messages.filter(m=>m.conversationId===c.id).sort((a,b)=>new Date(a.createdAt)-new Date(b.createdAt))};});
add('POST',/^\/api\/conversations\/([^/]+)\/messages$/,async ctx=>{const auth=requireAuth(ctx),db=readDb(),c=db.conversations.find(c=>c.id===ctx.match[1]);if(!c)throw new HttpError(404,'Görüşme bulunamadı.');if(c.customerId!==auth.sub&&c.sellerId!==auth.sub)throw new HttpError(403,'Bu görüşmeye mesaj gönderemezsiniz.');const b=await body(ctx.req),text=String(b.text||'').trim();if(!text)throw new HttpError(400,'Mesaj boş olamaz.');const message={id:id('msg'),conversationId:c.id,senderId:auth.sub,text:text.slice(0,1000),createdAt:new Date().toISOString()};db.messages.push(message);writeDb(db);return{status:201,data:{message}};});

function contentType(file){const ext=path.extname(file).toLowerCase();return ({'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'}[ext]||'application/octet-stream');}
function serveFile(res,file){try{const st=fs.statSync(file);if(!st.isFile())return false;res.writeHead(200,{'Content-Type':contentType(file),'Content-Length':st.size,'Cache-Control':file.endsWith('.html')?'no-cache':'public, max-age=3600'});fs.createReadStream(file).pipe(res);return true}catch{return false}}

const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    const pathname=decodeURIComponent(url.pathname);
    if(pathname.startsWith('/api/')){
      for(const r of routes){if(r.method!==req.method)continue;const match=pathname.match(r.pattern);if(!match)continue;const ctx={req,res,url,match};const result=await r.handler(ctx);if(result&&result.status)return json(res,result.status,result.data);return json(res,200,result??{});}
      throw new HttpError(404,'API adresi bulunamadı.');
    }
    const rel=pathname==='/'?'index.html':pathname.replace(/^\/+/,''),candidate=path.resolve(PUBLIC,rel);
    if(candidate.startsWith(PUBLIC)&&serveFile(res,candidate))return;
    serveFile(res,path.join(PUBLIC,'index.html'));
  }catch(e){if(!res.headersSent)json(res,e.status||500,{error:e.status?e.message:'Sunucuda bir hata oluştu.'});else res.end();if(!e.status)console.error(e);}
});

initializeDb().then(()=>server.listen(PORT,()=>console.log(`Hizmetim hazır: http://localhost:${PORT}`))).catch(err=>{console.error(err);process.exit(1)});
