# Hizmetim — Fullstack Mobil Demo

Bu sürüm, konuştuğumuz **İstanbul odaklı hizmet pazaryeri** demosudur.

## Çalışan özellikler

- Ana sayfa: önceki beğenilen mobil tasarım
- Story akışı
- Kategoriler
- **Terzi kategorisinde Udemy benzeri alt alta mağaza listesi**
- İstanbul'un 39 ilçesi
- En Yakın / En Uygun / Yüksek Puan / Bugün Müsait filtreleri
- Fiyat aralığı filtresi
- Mağaza detayı ve hizmet fiyatları
- Giriş / kayıt
- Müşteri ve mağaza sahibi hesap türleri
- Ücretsiz mağaza açma
- Mağaza sahibinin hizmet + fiyat eklemesi
- Telefondan fotoğraf seçerek 24 saatlik Story ekleme
- Yorum ve puan verme
- Favoriler
- Gerçek backend mesajlaşması
- Yemek/pasta için teslimat bilgisini mağaza profilinde gösterme

## Demo hesapları

Müşteri:
- E-posta: `musteri@hizmetim.demo`
- Şifre: `123456`

Mağaza sahibi:
- E-posta: `sevgi-terzi@hizmetim.demo`
- Şifre: `123456`

## Bilgisayarda / Render'da çalıştırma

Node.js 20+ yeterli. Harici paket yoktur.

```bash
npm start
```

Varsayılan adres: `http://localhost:3000`

## Render'a atarken

1. ZIP'i aç ve dosyaları GitHub deposuna yükle.
2. Render > New > Web Service > GitHub deponu seç.
3. Build Command: `echo "No build needed"`
4. Start Command: `npm start`
5. Environment Variable ekle: `TOKEN_SECRET` = uzun rastgele bir metin.
6. Deploy et.

`render.yaml` da projede hazırdır.

## Önemli: Bu sürüm demo veritabanı kullanıyor

Backend gerçek API ile çalışır ancak veriler şimdilik `data/db.json` dosyasında tutulur. Render'ın ücretsiz servisinde dosya sistemi kalıcı olmadığı için **sunucu yeniden oluşturulursa yeni kayıtlar, mesajlar ve kullanıcıların yüklediği Story'ler sıfırlanabilir**.

Site tasarımı ve akışı onaylandıktan sonraki adımda aynı API'yi **kalıcı Supabase/PostgreSQL veritabanına** bağlamak doğru üretim çözümüdür.

## Ana dosyalar

- `server.js` — backend API + web sunucusu
- `src/db.js` — demo veritabanı ve başlangıç verileri
- `src/auth.js` — şifre ve oturum sistemi
- `public/index.html` — mobil uygulama kabuğu
- `public/styles.css` — tasarım
- `public/app.js` — frontend, filtreler, mesajlar, Story vb.
