const state = {
  token: localStorage.getItem('hizmetim_token') || '',
  user: JSON.parse(localStorage.getItem('hizmetim_user') || 'null'),
  config: null, home: null, view:'home', location:'Başakşehir',
  currentCategory:null, categoryQuery:'', sort:'nearby', minPrice:'', maxPrice:'', availableToday:false,
  currentConversation:null, pending:null
};

const $ = s => document.querySelector(s);
const view = $('#view');
const overlay = $('#overlay');
const sheet = $('#sheet');
const bottomNav = $('#bottomNav');
const toastEl = $('#toast');

function esc(v=''){
  return String(v).replace(/[&<>'"]/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[c]));
}
function money(v){ return new Intl.NumberFormat('tr-TR').format(Number(v||0))+' TL'; }
function headers(extra={}){ return { 'Content-Type':'application/json', ...(state.token?{Authorization:`Bearer ${state.token}`}:{}) , ...extra}; }
async function api(url, opts={}){
  const res = await fetch(url, { ...opts, headers: headers(opts.headers||{}) });
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error || 'Bir hata oluştu.');
  return data;
}
function showToast(text){
  toastEl.textContent=text; toastEl.hidden=false;
  clearTimeout(showToast.t); showToast.t=setTimeout(()=>toastEl.hidden=true,1800);
}
function openSheet(html){ sheet.innerHTML=html; overlay.hidden=false; document.body.style.overflow='hidden'; }
function closeSheet(){ overlay.hidden=true; sheet.innerHTML=''; document.body.style.overflow=''; }
overlay.addEventListener('click',e=>{ if(e.target===overlay) closeSheet(); });
function setAuth(data){
  state.token=data.token; state.user=data.user;
  localStorage.setItem('hizmetim_token',data.token); localStorage.setItem('hizmetim_user',JSON.stringify(data.user));
}
function logout(){
  state.token=''; state.user=null; localStorage.removeItem('hizmetim_token'); localStorage.removeItem('hizmetim_user');
  showToast('Çıkış yapıldı'); renderHome();
}

function topbar({title='',back=false}={}){
  if(title){
    return `<header class="topbar">${back?`<button class="back" onclick="goBack()">‹</button>`:''}<div class="logo-mark">⌂</div><div class="brand">Hizmetim</div><div class="topbar-title">${esc(title)}</div></header>`;
  }
  return `<header class="topbar"><div class="logo-mark">⌂</div><div class="brand">Hizmetim</div><div class="top-actions">
    <button class="btn" onclick="openAuth('customer')">${state.user?'Profil':'Giriş Yap'}</button>
    <button class="btn primary" onclick="openStoreFlow()">Mağaza Aç</button>
  </div></header>`;
}
function renderNav(active='home'){
  bottomNav.innerHTML = [
    ['home','⌂','Ana Sayfa'],['categories','⊞','Kategoriler'],['messages','💬','Mesajlar'],['favorites','♡','Favoriler'],['profile','♙','Profil']
  ].map(([id,icon,label])=>`<button class="nav-btn ${active===id?'active':''}" onclick="navTo('${id}')"><b>${icon}</b>${label}</button>`).join('');
}
function navTo(id){
  if(id==='home') return renderHome();
  if(id==='categories') return renderCategoriesPage();
  if(id==='messages') return renderMessages();
  if(id==='favorites') return renderFavorites();
  if(id==='profile') return renderProfile();
}
function goBack(){
  if(state.view==='category') renderHome();
  else if(state.view==='conversation') renderMessages();
  else renderHome();
}

async function init(){
  try{
    state.config=await api('/api/config');
    if(state.token){
      try{ const me=await api('/api/me'); state.user=me.user; localStorage.setItem('hizmetim_user',JSON.stringify(me.user)); }
      catch{ state.token=''; state.user=null; localStorage.removeItem('hizmetim_token'); localStorage.removeItem('hizmetim_user'); }
    }
    await renderHome();
  }catch(e){ view.innerHTML=`<div class="empty"><h3>Demo başlatılamadı</h3><p>${esc(e.message)}</p></div>`; }
}

async function renderHome(){
  state.view='home'; state.home=await api('/api/home'); renderNav('home');
  const stories=state.home.stories.map(story=>`
    <button class="story" onclick="openStory('${story.id}')">
      <div class="story-ring"><img src="${story.image}" alt=""></div>
      <div class="story-name">${esc(story.store.name)}</div>
      <div class="story-note">${esc((story.caption||'Yeni story').slice(0,18))}</div>
    </button>`).join('');
  const cats=state.home.categories.map(c=>`<button class="category-btn" onclick="openCategory('${c.slug}')"><div class="category-icon">${c.icon}</div><span>${esc(c.name)}</span></button>`).join('');
  const cards=state.home.featured.slice(0,8).map(homeCard).join('');
  view.innerHTML=`<div class="page">${topbar()}
    <section class="hero">
      <div class="fieldbox">⌕ <input id="homeSearch" placeholder="Ne arıyorsun?" onkeydown="if(event.key==='Enter')homeSearch()"></div>
      <div class="fieldbox location">⌖ <span>İstanbul, ${esc(state.location)}</span><button onclick="openDistrictPicker()">⌄</button></div>
    </section>
    <section class="section"><div class="section-head"><h2>Bugün Neler Var?</h2><button class="link" onclick="showToast('Story akışı açıldı')">Tümünü Gör</button></div><div class="stories">${stories}</div></section>
    <div class="categories">${cats}</div>
    <section class="section"><div class="section-head"><h2>Öne Çıkan Mağazalar</h2><button class="link" onclick="renderCategoriesPage()">Tümünü Gör</button></div><div class="home-grid">${cards}</div></section>
    <div class="store-banner"><div class="emoji">🏪</div><div><h3>Kendi mağazanı aç</h3><p>Hizmetlerini İstanbul'da göster.</p></div><button class="btn primary" onclick="openStoreFlow()">Mağaza Aç</button></div>
  </div>`;
}
function homeCard(store){
  const sv=store.services.slice(0,2).map(s=>`<div class="price-line"><span>${esc(s.name)}</span><span class="price">${money(s.price)}</span></div>`).join('');
  return `<article class="home-card"><div class="home-img-wrap"><img class="home-img" src="${store.cover}" alt=""><button class="heart" onclick="event.stopPropagation();toggleFavorite('${store.id}',this)">♡</button></div>
    <div class="home-body"><div class="store-row"><img class="avatar" src="${store.avatar}" alt=""><div><div class="store-name">${esc(store.name)} <span class="verified">●</span></div><div class="muted">${esc(store.neighborhood||store.district)}</div></div></div>
    ${sv}<div class="rating">⭐ ${store.rating} <span class="muted">(${store.reviewCount})</span></div><div class="review-snippet">“Profili ve güncel fiyatları incele.”</div>
    <div class="card-actions"><button class="message" onclick="startMessage('${store.id}')">💬 Mesaj</button><button onclick="openStore('${store.id}')">Detaya Bak</button></div></div></article>`;
}
function homeSearch(){
  const q=$('#homeSearch').value.trim(); if(!q) return;
  const normalized=q.toLocaleLowerCase('tr');
  const cat=state.config.categories.find(c=>c.name.toLocaleLowerCase('tr').includes(normalized));
  if(cat) openCategory(cat.slug,q); else { state.categoryQuery=q; renderCategoriesPage(q); }
}

function renderCategoriesPage(q=''){
  state.view='categories'; renderNav('categories');
  view.innerHTML=`<div class="page">${topbar({title:'Kategoriler',back:true})}<section class="section"><div class="section-head"><h2>Hangi hizmeti arıyorsun?</h2></div>
    <div class="home-grid">${state.config.categories.map(c=>`<button class="home-card" style="padding:16px;border:1px solid var(--line)" onclick="openCategory('${c.slug}')"><div style="font-size:35px">${c.icon}</div><div style="font-weight:850;margin-top:7px">${esc(c.name)}</div></button>`).join('')}</div></section></div>`;
}

async function openCategory(slug,q=''){
  state.view='category'; state.currentCategory=slug; state.categoryQuery=q||''; state.sort='nearby'; state.minPrice=''; state.maxPrice=''; state.availableToday=false;
  await renderCategory();
}
async function renderCategory(){
  renderNav('categories');
  const params=new URLSearchParams();
  if(state.categoryQuery) params.set('q',state.categoryQuery);
  if(state.location) params.set('district',state.location);
  if(state.minPrice!=='') params.set('minPrice',state.minPrice);
  if(state.maxPrice!=='') params.set('maxPrice',state.maxPrice);
  if(state.sort) params.set('sort',state.sort);
  if(state.availableToday) params.set('availableToday','true');
  let data=await api(`/api/categories/${state.currentCategory}/stores?${params.toString()}`);
  // If selected district has no results, show all İstanbul instead of an empty category while keeping location visible.
  let showingAll=false;
  if(data.count===0 && state.location){
    const p2=new URLSearchParams(params); p2.delete('district'); data=await api(`/api/categories/${state.currentCategory}/stores?${p2.toString()}`); showingAll=true;
  }
  const priceLabel = state.minPrice!==''||state.maxPrice!=='' ? `${state.minPrice||0}–${state.maxPrice||'∞'} TL` : 'Fiyat Aralığı';
  view.innerHTML=`<div class="page category-page">${topbar({title:data.category.name,back:true})}
    <section class="hero"><div class="fieldbox">⌕ <input id="catSearch" value="${esc(state.categoryQuery)}" placeholder="${esc(data.category.name)} hizmeti ara..." oninput="debouncedCategorySearch(this.value)"></div>
    <div class="fieldbox location">⌖ <span>İstanbul, ${esc(state.location)}</span><button onclick="openDistrictPicker(true)">⌄</button></div></section>
    <div class="filter-row">
      <button class="filter-chip ${state.sort==='nearby'?'active':''}" onclick="setSort('nearby')">⌖ En Yakın</button>
      <button class="filter-chip ${state.minPrice!==''||state.maxPrice!==''?'active':''}" onclick="openPriceRange()">${esc(priceLabel)} ▾</button>
      <button class="filter-chip ${state.sort==='price'?'active':''}" onclick="setSort('price')">En Uygun</button>
      <button class="filter-chip ${state.sort==='rating'?'active':''}" onclick="setSort('rating')">Yüksek Puan</button>
      <button class="filter-chip ${state.availableToday?'active':''}" onclick="toggleToday()">▣ Bugün Müsait</button>
    </div>
    <div class="list-meta"><span>${data.count} ${esc(data.category.name.toLocaleLowerCase('tr'))} bulundu${showingAll?' • İstanbul geneli':''}</span><span>${state.minPrice!==''||state.maxPrice!==''?`Fiyat: ${esc(priceLabel)}`:''}</span></div>
    <div class="store-list">${data.stores.length?data.stores.map(listCard).join(''):`<div class="empty">Bu filtrelerde mağaza bulunamadı.</div>`}</div>
  </div>`;
}
function listCard(store){
  const chips=store.services.slice(0,3).map(s=>`<span class="service-chip">${esc(s.name)} <b>${money(s.price)}</b></span>`).join('');
  return `<article class="store-list-card"><img class="list-image" src="${store.cover}" alt=""><div class="list-main">
    <div class="list-top"><div><div class="list-name">${esc(store.name)} <span class="verified">●</span></div><div class="list-location">${esc(store.neighborhood||store.district)} • ${store.distanceKm} km</div><div class="rating">⭐ ${store.rating} <span class="muted">(${store.reviewCount})</span></div></div>
    <div class="start-price">Başlangıç Fiyatı<b>${store.minPrice!=null?money(store.minPrice)+'’den':'Sor'}</b></div></div>
    <div class="service-chips">${chips}${store.services.length>3?`<span class="service-chip">+${store.services.length-3} hizmet</span>`:''}</div>
    <div class="list-actions"><button class="message" onclick="startMessage('${store.id}')">💬 Mesaj Gönder</button><button onclick="openStore('${store.id}')">Detaya Bak</button><button class="favorite-mini" onclick="toggleFavorite('${store.id}',this)">♡</button></div>
  </div></article>`;
}
let searchTimer;
function debouncedCategorySearch(v){ clearTimeout(searchTimer); searchTimer=setTimeout(()=>{state.categoryQuery=v;renderCategory();},350); }
function setSort(sort){ state.sort=sort; renderCategory(); }
function toggleToday(){ state.availableToday=!state.availableToday; renderCategory(); }
function openPriceRange(){
  openSheet(`<div class="sheet-head"><h3>Fiyat Aralığı</h3><button class="close" onclick="closeSheet()">×</button></div><p class="hint">Başlangıç fiyatına göre mağazaları filtrele.</p>
    <div class="range-grid"><div><label class="form-label">En düşük</label><input id="minP" class="input" inputmode="numeric" value="${esc(state.minPrice)}" placeholder="0 TL"></div><div><label class="form-label">En yüksek</label><input id="maxP" class="input" inputmode="numeric" value="${esc(state.maxPrice)}" placeholder="1000 TL"></div></div>
    <button class="btn primary full" onclick="applyPrice()">Fiyatı Uygula</button><button class="btn full" style="margin-top:7px" onclick="clearPrice()">Temizle</button>`);
}
function applyPrice(){ state.minPrice=$('#minP').value.trim(); state.maxPrice=$('#maxP').value.trim(); closeSheet(); renderCategory(); }
function clearPrice(){ state.minPrice=''; state.maxPrice=''; closeSheet(); renderCategory(); }

function openDistrictPicker(fromCategory=false){
  const buttons=state.config.districts.map(d=>`<button class="district-btn" onclick="setDistrict('${d}',${fromCategory})">${esc(d)}</button>`).join('');
  openSheet(`<div class="sheet-head"><h3>İstanbul İlçesi Seç</h3><button class="close" onclick="closeSheet()">×</button></div><input class="input" placeholder="İlçe ara..." oninput="filterDistricts(this.value)"><div class="district-grid" id="districtGrid">${buttons}</div>`);
}
function filterDistricts(q){ const n=q.toLocaleLowerCase('tr'); document.querySelectorAll('.district-btn').forEach(b=>b.hidden=!b.textContent.toLocaleLowerCase('tr').includes(n)); }
function setDistrict(d,fromCategory){ state.location=d; closeSheet(); fromCategory?renderCategory():renderHome(); }

function openStory(id){
  const st=state.home?.stories.find(x=>x.id===id); if(!st) return;
  openSheet(`<div class="story-view"><img src="${st.image}" alt=""><div class="story-overlay"></div><div class="story-progress"><span></span></div><div class="story-user"><img src="${st.store.avatar}" alt=""><span>${esc(st.store.name)}</span><button class="close" onclick="closeSheet()">×</button></div><div class="story-caption">${esc(st.caption)}<small>Bugün • ${esc(st.store.neighborhood||st.store.district)}</small></div></div>`);
}

async function openStore(storeId){
  try{
    const data=await api(`/api/stores/${storeId}`); const s=data.store;
    const reviews=data.reviews.length?data.reviews.slice(0,5).map(r=>`<div class="review-item"><strong>${esc(r.user?.name||'Müşteri')} <span class="stars">${'★'.repeat(r.rating)}</span></strong>${esc(r.text)}</div>`).join(''):'<div class="hint">Henüz yeni yorum yok.</div>';
    openSheet(`<div class="sheet-head"><h3>Mağaza Detayı</h3><button class="close" onclick="closeSheet()">×</button></div>
      <div class="cover"><img src="${s.cover}" alt=""></div><div class="store-detail-title">${esc(s.name)} <span class="verified">●</span></div><div class="muted">${esc(s.neighborhood||'')}, ${esc(s.district)} • İstanbul</div>
      <div class="chips"><span class="chip">⭐ ${s.rating} (${s.reviewCount})</span><span class="chip">${s.availableToday?'Bugün müsait':'Randevu sor'}</span><span class="chip">${s.verified?'Doğrulanmış':'Yeni mağaza'}</span></div><p class="hint">${esc(s.description)}</p>
      <div class="detail-box"><b>Hizmetler ve fiyatlar</b><div class="service-list">${s.services.map(x=>`<div class="service-line"><span>${esc(x.name)}</span><b class="price">${money(x.price)}</b></div>`).join('')}</div></div>
      <div class="detail-box"><b>Teslimat / çalışma şekli</b><div class="hint" style="margin-top:5px">${(s.deliveryMethods||[]).map(esc).join(' • ')}</div></div>
      <h4>Yorumlar</h4>${reviews}
      <div class="detail-actions"><button class="btn primary" onclick="closeSheet();startMessage('${s.id}')">💬 Mesaj Gönder</button><button class="btn" onclick="openReview('${s.id}')">Yorum Yaz</button></div>`);
  }catch(e){ showToast(e.message); }
}
async function openReview(storeId){
  if(!ensureCustomer(()=>openReview(storeId))) return;
  openSheet(`<div class="sheet-head"><h3>Yorum Yaz</h3><button class="close" onclick="closeSheet()">×</button></div><label class="form-label">Puan</label><select id="reviewRating" class="select"><option value="5">5 - Çok iyi</option><option value="4">4 - İyi</option><option value="3">3 - Orta</option><option value="2">2 - Kötü</option><option value="1">1 - Çok kötü</option></select><label class="form-label">Yorumun</label><textarea id="reviewText" class="textarea" placeholder="Deneyimini yaz..."></textarea><button class="btn primary full" onclick="submitReview('${storeId}')">Yorumu Gönder</button>`);
}
async function submitReview(storeId){
  try{ await api(`/api/stores/${storeId}/reviews`,{method:'POST',body:JSON.stringify({rating:Number($('#reviewRating').value),text:$('#reviewText').value})}); closeSheet();showToast('Yorum gönderildi'); }
  catch(e){showToast(e.message)}
}
async function toggleFavorite(storeId,btn){
  if(!ensureCustomer(()=>toggleFavorite(storeId,btn))) return;
  try{ const r=await api(`/api/favorites/${storeId}`,{method:'POST'}); if(btn) btn.textContent=r.favorite?'♥':'♡'; showToast(r.favorite?'Favorilere eklendi':'Favorilerden çıkarıldı'); }
  catch(e){showToast(e.message)}
}

function ensureCustomer(after){
  if(!state.user){ state.pending=after; openAuth('customer'); return false; }
  if(state.user.role!=='customer'){ showToast('Bu işlem için müşteri hesabı gerekiyor'); return false; }
  return true;
}
async function startMessage(storeId){
  if(!ensureCustomer(()=>startMessage(storeId))) return;
  try{ const {conversation}=await api('/api/conversations',{method:'POST',body:JSON.stringify({storeId})}); closeSheet(); openConversation(conversation.id); }
  catch(e){showToast(e.message)}
}
async function renderMessages(){
  state.view='messages'; renderNav('messages');
  if(!state.user){ view.innerHTML=`<div class="page">${topbar({title:'Mesajlar',back:true})}<div class="empty">Mesajlarını görmek için giriş yap.<br><br><button class="btn primary" onclick="openAuth('customer')">Giriş Yap</button></div></div>`; return; }
  try{
    const data=await api('/api/conversations');
    view.innerHTML=`<div class="page">${topbar({title:'Mesajlar',back:true})}<section class="section">${data.conversations.length?`<div class="conversation-list">${data.conversations.map(c=>`<button class="conversation-item" onclick="openConversation('${c.id}')"><img src="${c.store?.avatar||'/assets/generic.jpg'}"><div class="conversation-main"><b>${esc(c.store?.name||c.other?.name||'Görüşme')}</b><div class="conversation-preview">${esc(c.lastMessage?.text||'Henüz mesaj yok')}</div></div><span>›</span></button>`).join('')}</div>`:`<div class="empty">Henüz mesajın yok.<br>Bir mağazaya “Mesaj Gönder” diyerek başlayabilirsin.</div>`}</section></div>`;
  }catch(e){showToast(e.message)}
}
async function openConversation(id){
  state.view='conversation'; state.currentConversation=id; renderNav('messages');
  const list=await api('/api/conversations'); const conv=list.conversations.find(c=>c.id===id);
  const data=await api(`/api/conversations/${id}/messages`);
  view.innerHTML=`<div class="page">${topbar({title:conv?.store?.name||'Mesajlaşma',back:true})}<section class="section"><div class="hint">Güvenli site içi mesajlaşma • Teslimat ve hizmet detayını burada konuşabilirsiniz.</div><div id="chatbox" class="chatbox">${data.messages.map(m=>`<div class="bubble ${m.senderId===state.user.id?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="send-row"><input id="msgText" class="input" placeholder="Mesajını yaz..." onkeydown="if(event.key==='Enter')sendMessage()"><button class="btn primary" onclick="sendMessage()">Gönder</button></div></section></div>`;
  setTimeout(()=>{ const b=$('#chatbox'); if(b)b.scrollTop=b.scrollHeight; },30);
}
async function sendMessage(){
  const el=$('#msgText'); const text=el?.value.trim(); if(!text)return;
  try{ await api(`/api/conversations/${state.currentConversation}/messages`,{method:'POST',body:JSON.stringify({text})}); await openConversation(state.currentConversation); }
  catch(e){showToast(e.message)}
}

async function renderFavorites(){
  state.view='favorites'; renderNav('favorites');
  if(!state.user){ view.innerHTML=`<div class="page">${topbar({title:'Favoriler',back:true})}<div class="empty">Favorilerini görmek için giriş yap.<br><br><button class="btn primary" onclick="openAuth('customer')">Giriş Yap</button></div></div>`; return; }
  if(state.user.role!=='customer'){ view.innerHTML=`<div class="page">${topbar({title:'Favoriler',back:true})}<div class="empty">Favoriler müşteri hesabına özeldir.</div></div>`; return; }
  try{ const data=await api('/api/favorites'); view.innerHTML=`<div class="page">${topbar({title:'Favoriler',back:true})}<section class="section"><div class="home-grid">${data.stores.map(homeCard).join('')}</div>${!data.stores.length?'<div class="empty">Henüz favori mağazan yok.</div>':''}</section></div>`; }
  catch(e){showToast(e.message)}
}

async function renderProfile(){
  state.view='profile'; renderNav('profile');
  if(!state.user){ view.innerHTML=`<div class="page">${topbar({title:'Profil',back:true})}<div class="empty">Profilini kullanmak için giriş yap.<br><br><button class="btn primary" onclick="openAuth('customer')">Giriş / Kayıt</button></div></div>`; return; }
  try{
    const me=await api('/api/me'); const s=me.store;
    view.innerHTML=`<div class="page">${topbar({title:'Profil',back:true})}<div class="profile-head"><div class="profile-avatar">${state.user.role==='seller'?'🏪':'👤'}</div><h2>${esc(state.user.name)}</h2><div class="muted">${esc(state.user.email)} • ${state.user.role==='seller'?'Mağaza sahibi':'Müşteri'}</div></div>
      ${state.user.role==='seller'?`<div class="seller-panel">${s?`<div class="seller-card"><h3>${esc(s.name)}</h3><div class="hint">${esc(s.neighborhood||'')}, ${esc(s.district)} • ${esc(state.config.categories.find(c=>c.slug===s.categorySlug)?.name||'')}</div><div class="seller-controls"><button class="btn primary" onclick="openAddStory('${s.id}')">＋ Story Ekle</button><button class="btn" onclick="openAddService('${s.id}')">＋ Hizmet Ekle</button><button class="btn" onclick="openStore('${s.id}')">Mağazayı Gör</button><button class="btn" onclick="showToast('Mağaza düzenleme sonraki adımda genişletilebilir')">Düzenle</button></div></div>`:`<div class="empty">Henüz mağazan yok.<br><br><button class="btn primary" onclick="openStoreCreator()">Ücretsiz Mağaza Aç</button></div>`}</div>`:`<div class="profile-actions"><button onclick="renderFavorites()">♡ Favorilerim</button><button onclick="renderMessages()">💬 Mesajlarım</button></div>`}
      <div class="profile-actions"><button onclick="logout()">Çıkış Yap</button></div></div>`;
  }catch(e){showToast(e.message)}
}

function openAuth(preferredRole='customer'){
  if(state.user){ renderProfile(); return; }
  openSheet(authHtml('login',preferredRole));
}
function authHtml(mode='login',role='customer'){
  const login=mode==='login';
  return `<div class="sheet-head"><h3>${login?'Giriş Yap':'Kayıt Ol'}</h3><button class="close" onclick="closeSheet()">×</button></div>
    <div class="choice-grid"><button class="choice ${role==='customer'?'active':''}" onclick="openSheet(authHtml('${mode}','customer'))">👤<br><b>Müşteri</b><div class="hint">Hizmet arıyorum</div></button><button class="choice ${role==='seller'?'active':''}" onclick="openSheet(authHtml('${mode}','seller'))">🏪<br><b>Mağaza Sahibi</b><div class="hint">Hizmet sunacağım</div></button></div>
    ${!login?`<input id="authName" class="input" placeholder="Ad Soyad / Mağaza sahibi adı">`:''}<input id="authEmail" class="input" type="email" placeholder="E-posta"><input id="authPass" class="input" type="password" placeholder="Şifre (en az 6 karakter)">
    <button class="btn primary full" onclick="submitAuth('${mode}','${role}')">${login?'Giriş Yap':'Kayıt Ol'}</button>
    <button class="btn full" style="margin-top:7px" onclick="openSheet(authHtml('${login?'register':'login'}','${role}'))">${login?'Hesabın yok mu? Kayıt Ol':'Zaten hesabın var mı? Giriş Yap'}</button>
    <div class="demo-box"><b>Demo hesaplar</b><br>Müşteri: musteri@hizmetim.demo / 123456<br>Mağaza: sevgi-terzi@hizmetim.demo / 123456</div>`;
}
async function submitAuth(mode,role){
  try{
    const body={email:$('#authEmail').value.trim(),password:$('#authPass').value,role}; if(mode==='register')body.name=$('#authName').value.trim();
    const data=await api(`/api/auth/${mode==='register'?'register':'login'}`,{method:'POST',body:JSON.stringify(body)}); setAuth(data); closeSheet(); showToast(mode==='register'?'Kayıt tamamlandı':'Giriş yapıldı');
    const pending=state.pending; state.pending=null;
    if(pending) return pending();
    if(role==='seller') openStoreFlow(); else renderHome();
  }catch(e){showToast(e.message)}
}

async function openStoreFlow(){
  if(!state.user){ state.pending=()=>openStoreFlow(); openAuth('seller'); return; }
  if(state.user.role!=='seller'){ showToast('Mağaza açmak için mağaza sahibi hesabı gerekiyor'); return; }
  const me=await api('/api/me'); if(me.store){ renderProfile(); } else openStoreCreator();
}
function openStoreCreator(){
  const catOptions=state.config.categories.map(c=>`<option value="${c.slug}">${esc(c.name)}</option>`).join('');
  const districtOptions=state.config.districts.map(d=>`<option value="${d}" ${d===state.location?'selected':''}>${esc(d)}</option>`).join('');
  openSheet(`<div class="sheet-head"><h3>Ücretsiz Mağaza Aç</h3><button class="close" onclick="closeSheet()">×</button></div><p class="hint">İlk sürümde mağaza açmak ve müşterilerle mesajlaşmak ücretsiz.</p><label class="form-label">Mağaza adı</label><input id="storeName" class="input" placeholder="Örn. Nermin'in Mutfağı"><label class="form-label">Kategori</label><select id="storeCat" class="select">${catOptions}</select><label class="form-label">İlçe</label><select id="storeDistrict" class="select">${districtOptions}</select><label class="form-label">Mahalle / bölge</label><input id="storeNeighborhood" class="input" placeholder="Örn. Bahçeşehir"><label class="form-label">Kısa açıklama</label><textarea id="storeDescription" class="textarea" placeholder="Neler yapıyorsun?"></textarea><button class="btn primary full" onclick="createStore()">Mağazayı Oluştur</button>`);
}
async function createStore(){
  try{ const body={name:$('#storeName').value.trim(),categorySlug:$('#storeCat').value,district:$('#storeDistrict').value,neighborhood:$('#storeNeighborhood').value.trim(),description:$('#storeDescription').value.trim()}; await api('/api/stores',{method:'POST',body:JSON.stringify(body)}); closeSheet();showToast('Mağaza açıldı');renderProfile(); }
  catch(e){showToast(e.message)}
}
function openAddService(storeId){
  openSheet(`<div class="sheet-head"><h3>Hizmet Ekle</h3><button class="close" onclick="closeSheet()">×</button></div><input id="svcName" class="input" placeholder="Hizmet adı"><input id="svcPrice" class="input" inputmode="numeric" placeholder="Fiyat (TL)"><button class="btn primary full" onclick="addService('${storeId}')">Hizmeti Ekle</button>`);
}
async function addService(storeId){
  try{ await api(`/api/stores/${storeId}/services`,{method:'POST',body:JSON.stringify({name:$('#svcName').value.trim(),price:Number($('#svcPrice').value)})});closeSheet();showToast('Hizmet eklendi');renderProfile(); }
  catch(e){showToast(e.message)}
}
function openAddStory(){
  openSheet(`<div class="sheet-head"><h3>Story Ekle</h3><button class="close" onclick="closeSheet()">×</button></div><p class="hint">Telefondan fotoğraf seç. Story 24 saat görünür.</p><input id="storyFile" class="input" type="file" accept="image/*"><textarea id="storyCaption" class="textarea" placeholder="Bugün ne yaptın? Örn. Taze pastalar hazır 🍰"></textarea><button class="btn primary full" onclick="addStory()">Story'yi Yayınla</button>`);
}
async function addStory(){
  const file=$('#storyFile').files[0]; if(!file){showToast('Bir fotoğraf seç');return;} if(file.size>4*1024*1024){showToast('Fotoğraf 4 MB’dan küçük olsun');return;}
  const reader=new FileReader(); reader.onload=async()=>{ try{ await api('/api/stories',{method:'POST',body:JSON.stringify({imageData:reader.result,caption:$('#storyCaption').value.trim()})});closeSheet();showToast('Story yayınlandı');renderProfile(); }catch(e){showToast(e.message)} }; reader.readAsDataURL(file);
}

init();
