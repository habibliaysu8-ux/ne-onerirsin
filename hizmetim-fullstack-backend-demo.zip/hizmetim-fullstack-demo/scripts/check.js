const { initializeDb, readDb } = require('../src/db');
const { verifyPassword } = require('../src/auth');
(async()=>{
  await initializeDb();
  const db=readDb();
  const tailors=db.stores.filter(s=>s.categorySlug==='terzi');
  const demo=db.users.find(u=>u.email==='musteri@hizmetim.demo');
  if(!db.stores.length||tailors.length<6||!demo||!verifyPassword('123456',demo.passwordHash)) throw new Error('Demo verisi doğrulanamadı');
  console.log(`OK: ${db.stores.length} mağaza, ${tailors.length} terzi, ${db.users.length} kullanıcı, demo giriş çalışıyor`);
})().catch(e=>{console.error(e);process.exit(1)});
